#include "validation.h"
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
#include <stdbool.h>

// ---------- String & Character Validation ----------

bool is_valid_length(const char* str, int min_len, int max_len) {
    return strlen(str) <= max_len;
}

bool is_min_length(const char* str, int min_len) {
    return strlen(str) >= min_len;
}

bool is_empty(const char* str) {
    return str == NULL || str[0] == '\0';
}

bool is_alphanumeric(const char* str) {
    for (int i = 0; str[i]; i++) {
        if (!isalnum((unsigned char)str[i])) return false;
    }
    return true;
}

bool is_alpha(const char* str) {
    for (int i = 0; str[i]; i++) {
        if (!isalpha((unsigned char)str[i])) return false;
    }
    return true;
}

bool is_numeric(const char* str) {
    for (int i = 0; str[i]; i++) {
        if (!isdigit((unsigned char)str[i])) return false;
    }
    return true;
}

bool is_printable(const char* str) {
    for (int i = 0; str[i]; i++) {
        if (!isprint((unsigned char)str[i])) return false;
    }
    return true;
}

bool contains_whitespace(const char* str) {
    for (int i = 0; str[i]; i++) {
        if (isspace((unsigned char)str[i])) return true;
    }
    return false;
}

bool is_uppercase(const char* str) {
    for (int i = 0; str[i]; i++) {
        if (!isupper((unsigned char)str[i])) return false;
    }
    return true;
}

bool is_lowercase(const char* str) {
    for (int i = 0; str[i]; i++) {
        if (!islower((unsigned char)str[i])) return false;
    }
    return true;
}

// ---------- Pattern Matching ----------

bool is_valid_email(const char* email) {
    const char* at = strchr(email, '@');
    if (!at || at == email) return false;
    const char* dot = strchr(at, '.');
    if (!dot || dot <= at + 1 || dot[1] == '\0') return false;
    return true;
}

bool is_valid_phone(const char* phone) {
    for (int i = 0; phone[i]; i++) {
        if (!isdigit(phone[i]) && phone[i] != '+' && phone[i] != '-') return false;
    }
    return true;
}

bool is_valid_url(const char* url) {
    return strncmp(url, "http://", 7) == 0 || strncmp(url, "https://", 8) == 0;
}

bool is_valid_ipv4(const char* ip) {
    int segs = 0;
    int num;
    char c;
    while (*ip) {
        if (!isdigit(*ip)) return false;
        num = 0;
        while (*ip && isdigit(*ip)) {
            num = num * 10 + (*ip - '0');
            ip++;
        }
        if (num < 0 || num > 255) return false;
        segs++;
        if (*ip == '.') ip++;
        else break;
    }
    return segs == 4 && *ip == '\0';
}

bool is_valid_hex(const char* str) {
    for (int i = 0; str[i]; i++) {
        if (!isxdigit((unsigned char)str[i])) return false;
    }
    return true;
}

// ---------- Integer & Numeric ----------

bool is_int(const char* str) {
    if (*str == '-' || *str == '+') str++;
    if (!*str) return false;
    while (*str) {
        if (!isdigit(*str)) return false;
        str++;
    }
    return true;
}

bool is_float(const char* str) {
    char* endptr;
    strtod(str, &endptr);
    return *endptr == '\0';
}

bool is_in_range(int val, int min, int max) {
    return val >= min && val <= max;
}

bool will_int_overflow(int a, int b) {
    if ((b > 0) && (a > INT_MAX - b)) return true;
    if ((b < 0) && (a < INT_MIN - b)) return true;
    return false;
}

bool will_int_underflow(int a, int b) {
    return will_int_overflow(a, b);
}

bool is_power_of_two(int x) {
    return x > 0 && (x & (x - 1)) == 0;
}

bool is_even(int x) {
    return (x % 2) == 0;
}

bool is_odd(int x) {
    return (x % 2) != 0;
}



// Function to check for overflow on addition
bool will_add_overflow(int16_t x, int16_t y) {
    if (y > 0 && x > INT16_MAX - y) return true;  // Positive overflow
    if (y < 0 && x < INT16_MIN - y) return true;  // Negative overflow
    return false;
}

// Function to check for overflow on multiplication
bool will_multiply_overflow(int16_t x, int16_t y) {
    if (x > 0 && y > 0 && x > INT16_MAX / y) return true;
    if (x < 0 && y < 0 && x < INT16_MAX / y) return true;
    if (x > 0 && y < 0 && y < INT16_MIN / x) return true;
    if (x < 0 && y > 0 && x < INT16_MIN / y) return true;
    return false;
}

// Function to check for overflow on subtraction
bool will_subtract_overflow(int16_t x, int16_t y) {
    if (y > 0 && x < INT16_MIN + y) return true;  // Negative overflow
    if (y < 0 && x > INT16_MAX + y) return true;  // Positive overflow
    return false;
}

// ---------- Buffer / Memory ----------

bool safe_copy_string(char* dest, const char* src, size_t dest_size) {
    if (strlen(src) >= dest_size) return false;
    strncpy(dest, src, dest_size);
    dest[dest_size - 1] = '\0';
    return true;
}

bool is_safe_to_concatenate(char* dest, const char* src, size_t dest_size) {
    return strlen(dest) + strlen(src) < dest_size;
}

bool is_within_buffer(const void* ptr, const void* base, size_t total_size) {
    return (const char*)ptr >= (const char*)base && (const char*)ptr < ((const char*)base + total_size);
}

// ---------- Stack / Recursive ----------

void simulate_stack_overflow(int depth) {
    char buffer[1000];
    printf("Stack depth: %d\n", depth);
    simulate_stack_overflow(depth + 1);
}

// ---------- Security ----------

bool contains_sql_injection_pattern(const char* input) {
    return strstr(input, "--") || strstr(input, "'") || strstr(input, ";") || strstr(input, "/*") || strstr(input, "xp_");
}

bool contains_xss_pattern(const char* input) {
    return strstr(input, "<script") || strstr(input, "onerror=") || strstr(input, "javascript:");
}

bool is_valid_password(const char* pwd) {
    if (strlen(pwd) < 8) return false;
    bool has_upper = false, has_lower = false, has_digit = false;
    for (int i = 0; pwd[i]; i++) {
        if (isupper((unsigned char)pwd[i])) has_upper = true;
        if (islower((unsigned char)pwd[i])) has_lower = true;
        if (isdigit((unsigned char)pwd[i])) has_digit = true;
    }
    return has_upper && has_lower && has_digit;
}
