#include<stdio.h>
#include<string.h>

#define LEN 8


