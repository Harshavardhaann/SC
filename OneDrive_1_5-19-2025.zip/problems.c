#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<string.h>
#include<stdint-gcc.h>
#include <stdbool.h>
#include "validation.h"
#include "test.h"

#define LEN 8
#define MAX_INPUT 15


void problem1(char *src){

    char dest[LEN];
    char buf[LEN];

    strcpy(dest, src);
    strcpy(buf, dest);

    printf("\n Destination string = %s and buf string = %s", dest, buf);
}

char * copy_string(char *input, char *buf)
{

    int i;

    for(i=0 ; input[i] != '\0'; i++)
        buf[i] = input[i];

    return buf;
}


int16_t * get_mem(int16_t size)
{
    int *buf;

    buf = (int *)malloc(sizeof(int) * size);

    if(buf != NULL) return buf;
}


int16_t operations(int16_t x, int16_t y,int option)
{
    if(option = 1) return x + y;
    else if(option = 2) return x * y;
    else if(option = 3 ) return x - y;
}


//HINT: use canary
void problem5()
{
    char bufer[10] = "Felicity";
    char tgt[LEN];

    strcpy(tgt,bufer);
    char str[5]="WIN";

    printf("%c, %c, %c, %c",str[5], str[6], str[7], str[8]);
}

void prompt_input(const char* prompt, char* buffer, size_t size) {
    printf("%s: ", prompt);
    fgets(buffer, size, stdin);
    buffer[strcspn(buffer, "\n")] = '\0';  // remove newline
    }

void test_validation()
{



    char name[MAX_INPUT];
    char email[MAX_INPUT];
    char phone[MAX_INPUT];
    char password[MAX_INPUT];
    char age_str[MAX_INPUT];
    int age;

    printf("User Registration\n\n");


    while (1) {
        prompt_input("Enter your name", name, sizeof(name));
        // TODO: Validate name
        if (1/* Name validation here */) {
            printf("Name must be alphabetic and between 2�30 characters.\n");
        } else break;
    }

    // Email validation
    while (1) {
        prompt_input("Enter your email", email, sizeof(email));
        // TODO: Validate email
        if (1/* Email validation here */) {
            printf("Invalid email format.\n");
        } else break;
    }

    // Phone validation
    while (1) {
        prompt_input("Enter your phone number", phone, sizeof(phone));
        // TODO: Validate phone and length check
        if (1/* Phone validation here */) {
            printf("Phone must be at least 10 digits.\n");
        } else break;
    }

    // Password validation
    while (1) {
        prompt_input("Create a password", password, sizeof(password));
        // TODO: Validate password
        if (1/* Password validation here */) {
            printf("Password must be 8+ chars and include mixed case, numbers, symbols.\n");
        } else break;
    }

    //Age (Integer overflow safe)
    while (1) {
        prompt_input("Enter your age", age_str, sizeof(age_str));
        // TODO: Validate if age is numeric and in range
        if (1/* Age validation here */) {
            printf("Age must be a number between 0 and 120.\n");
        } else break;
    }

    printf("\nRegistration Successful!\n");
    printf("Name: %s\nEmail: %s\nPhone: %s\nAge: %d\n", name, email, phone, age);

}
