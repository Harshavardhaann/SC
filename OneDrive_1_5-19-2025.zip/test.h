#include <stdint-gcc.h>

void problem1(char *);
char * copy_string(char *, char *);
int16_t * get_mem(int16_t);
int16_t operations(int16_t, int16_t, int);
void problem5();
void test_validation();
