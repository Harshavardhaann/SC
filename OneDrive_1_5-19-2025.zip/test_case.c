#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <stdbool.h>
#include "validation.h"  // Include the header file where your validation functions are defined

void test_is_alpha() {
    assert(is_alpha("Hello") == 1);  // Should return 1 (true) because "Hello" is alphabetic
    assert(is_alpha("Hello123") == 0);  // Should return 0 (false) because it contains numbers
    assert(is_alpha("123") == 0);  // Should return 0 (false) because it's numeric
    assert(is_alpha("") == 0);  // Should return 0 (false) because empty string is not valid
}

void test_is_numeric() {
    assert(is_numeric("12345") == 1);  // Should return 1 (true) because it's numeric
    assert(is_numeric("123a") == 0);  // Should return 0 (false) because it contains a letter
    assert(is_numeric("123 45") == 0);  // Should return 0 (false) because it contains a space
    assert(is_numeric("") == 0);  // Should return 0 (false) for empty string
}

void test_is_valid_email() {
    assert(is_valid_email("test@example.com") == 1);  // Valid email format
    assert(is_valid_email("test@com") == 0);  // Invalid email (no domain)
    assert(is_valid_email("test@.com") == 0);  // Invalid email (no username)
    assert(is_valid_email("test@com.") == 0);  // Invalid email (trailing dot)
    assert(is_valid_email("test123@example.com") == 1);  // Valid email format with numbers
}

void test_is_valid_password() {
    assert(is_valid_password("Password123!") == 1);  // Valid password (length, complexity)
    assert(is_valid_password("password") == 0);  // Invalid password (no uppercase, no numbers, no symbols)
    assert(is_valid_password("P@ss123") == 1);  // Valid password (meets complexity)
    assert(is_valid_password("short") == 0);  // Invalid password (too short)
    assert(is_valid_password("P@ss1") == 0);  // Invalid password (too short)
}

void test_is_in_range() {
    assert(is_in_range(5, 0, 10) == 1);  // 5 is in the range 0 to 10
    assert(is_in_range(15, 0, 10) == 0);  // 15 is outside the range 0 to 10
    assert(is_in_range(0, 0, 0) == 1);  // 0 is exactly within the range 0 to 0
    assert(is_in_range(10, 0, 10) == 1);  // 10 is on the upper boundary (valid)
}

void test_is_min_length() {
    assert(is_min_length("Hello", 3) == 1);  // "Hello" has length 5, valid for min length 3
    assert(is_min_length("Hi", 3) == 0);  // "Hi" has length 2, invalid for min length 3
    assert(is_min_length("A", 1) == 1);  // "A" has length 1, valid for min length 1
    assert(is_min_length("", 1) == 0);  // Empty string is invalid for min length 1
}

void test_is_valid_length() {
    assert(is_valid_length("Hello", 3, 10) == 1);  // "Hello" has length 5, valid for length 3 to 10
    assert(is_valid_length("Hi", 3, 10) == 0);  // "Hi" has length 2, invalid for length 3 to 10
    assert(is_valid_length("A very long string", 3, 10) == 0);  // Too long for length 3 to 10
    assert(is_valid_length("Valid", 3, 5) == 1);  // "Valid" has length 5, valid for length 3 to 5
}

void test_contains_whitespace() {
    assert(contains_whitespace("Hello World") == 1);  // Contains a space, so returns true
    assert(contains_whitespace("Hello") == 0);  // No spaces, returns false
    assert(contains_whitespace("123 456") == 1);  // Contains a space, returns true
    assert(contains_whitespace("NoSpace") == 0);  // No space, returns false
}

void test_is_printable() {
    assert(is_printable("Hello") == 1);  // All printable characters
    assert(is_printable("Hello\n") == 0);  // Contains newline (non-printable)
    assert(is_printable("Test123!") == 1);  // All printable characters
    assert(is_printable("Good\to") == 0);  // Contains tab (non-printable)
}

void test_is_power_of_two() {
    assert(is_power_of_two(2) == 1);  // 2 is a power of two
    assert(is_power_of_two(4) == 1);  // 4 is a power of two
    assert(is_power_of_two(7) == 0);  // 7 is not a power of two
    assert(is_power_of_two(8) == 1);  // 8 is a power of two
    assert(is_power_of_two(16) == 1);  // 16 is a power of two
}

void test_will_int_overflow() {
    assert(will_int_overflow(32000, 1000) == 1);  // Will overflow on addition (int16_t)
    assert(will_int_overflow(-32000, -1000) == 1);  // Will overflow on addition (int16_t)
    assert(will_int_overflow(3000, 2000) == 0);  // No overflow
    assert(will_int_overflow(1000, 1000) == 0);  // No overflow
}

void test_simulate_stack_overflow() {
    // Stack overflow test will be more difficult to handle with assertions. This is just for the understanding
    // You could create a safe test that simulates a controlled overflow
    // For instance:
    int depth = 1000;  // A safe recursion depth for most systems
    simulate_stack_overflow(depth);
    assert(depth == 1000);  // Check if depth is maintained after simulation (a basic test)
}

