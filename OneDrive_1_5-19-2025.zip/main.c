#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "test.h"

#define LEN 20


int main()
{
    char *result;
    int *arr;


    /* General instruction
    1. Test individual exercise by commenting rest of the functions
    2. First crash the code with different set of inputs
    3. Note down the type of issue (validation, buffer overflow, stack smashing, integer overflow etc.
    4. Use appropriate function from validation.h file to mitigate the issue
    5. Test again whether the issues are resolved
    */

    /* Exercise 1: Figure out the issue with code and rectify the code with required validations.*/

    problem1("Cyber");
  //  problem1("All the best");

    /* Exercise 2: Identify the issue with the code and fix the code */

  //  result = copy_string("Its a great day",result);
   // printf("Result = %s", result);

 //   result = copy_string("compare",result);
  //  printf("Result = %s", result);

    /*Exercise 3: Identify the issue and mention the steps to mitigate the issue */

  //  arr = get_mem(LEN);
  //  arr[LEN - 1] = 10;
  //  printf("\n Last digit = %d", arr[LEN - 1]);



    /*Exercise 4: Identify the issue and fix the code */

  //  printf("result  = %d", operations(10,20, 1));
  //  printf("result  = %d", operations(10,20, 2));
  //  printf("result  = %d", operations(10,20, 3));



    /* Exercise 5: Identify the issue and mention the steps to mitigate the issues */
 //   problem5();


    /*Exercise 6: use appropriate validation function to validate and sanitize the input */
    test_validation();

    /* Exercise 7: test all the functions in validation.h header file */

    return 0;
}


