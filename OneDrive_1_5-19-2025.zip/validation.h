#ifndef VALIDATION_H
#define VALIDATION_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint-gcc.h>

// ---------- String & Character Validation ----------
bool is_valid_length(const char* str,int min_len, int max_len);
bool is_min_length(const char* str, int min_len);
bool is_empty(const char* str);
bool is_alphanumeric(const char* str);
bool is_alpha(const char* str);
bool is_numeric(const char* str);
bool is_printable(const char* str);
bool contains_whitespace(const char* str);
bool is_uppercase(const char* str);
bool is_lowercase(const char* str);

// ---------- Pattern Matching ----------
bool is_valid_email(const char* email);
bool is_valid_phone(const char* phone);
bool is_valid_url(const char* url);
bool is_valid_ipv4(const char* ip);
bool is_valid_hex(const char* str);

// ---------- Integer & Numeric Validation ----------
bool is_int(const char* str);
bool is_float(const char* str);
bool is_in_range(int val, int min, int max);
bool will_int_overflow(int a, int b);
bool will_int_underflow(int a, int b);
bool is_power_of_two(int x);
bool is_even(int x);
bool is_odd(int x);
bool will_add_overflow(int16_t x, int16_t y);
bool will_multiply_overflow(int16_t x, int16_t y);
bool will_subtract_overflow(int16_t x, int16_t y);

// ---------- Buffer / Memory Validation ----------
bool safe_copy_string(char* dest, const char* src, size_t dest_size);
bool is_safe_to_concatenate(char* dest, const char* src, size_t dest_size);
bool is_within_buffer(const void* ptr, const void* base, size_t total_size);

// ---------- Stack / Recursion ----------
void simulate_stack_overflow(int depth);

// ---------- Security ----------
bool contains_sql_injection_pattern(const char* input);
bool contains_xss_pattern(const char* input);
bool is_valid_password(const char* pwd);

#endif // VALIDATION_H
